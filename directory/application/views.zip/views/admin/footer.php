    
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
    <!-- <script type="text/javascript" src="assets/plugins/jquery-ui/jquery-ui-1.10.3.custom.js"></script> -->
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/common/jquery.blockUI.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/common/jquery.event.move.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/common/lodash.compat.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/common/respond.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/common/excanvas.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/common/breakpoints.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/common/touch-punch.min.js"></script>
    
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/zurbResTable/responsive-tables.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/plugins/footable/js/footable.min.js"></script>

    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/app.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/plugins.js"></script>
    
    <script>
        $(document).ready(function(){
            App.init();
            $('.footable').footable();
        });        
    </script>
    
</body>

<!-- Mirrored from flatsquare.themesway.com/blue/tables-responsive.html by HTTrack Website Copier/3.x [XR&CO'2013], Tue, 24 Dec 2013 13:08:24 GMT -->
</html>