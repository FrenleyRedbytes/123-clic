<div id="sidebar" class="sidebar-fixed">    <!-- Start : Side bar -->

            <div id="sidebar-content">  <!-- Start : Side bar content -->
                
                <ul id="nav">   <!-- Start : Side bar Menu Items -->
                    
                    <li >
                        <a href="dashboard.php">
                            <i class="fa fa-dashboard"></i>SAYSO Dashboard <span ></span>
                        </a>
                    </li>
                   
                    <li>
                        <a href="image.php">
                            <i class="fa fa-tasks" aria-hidden="true"></i>Create Images
                        </a>
                    </li>
                 
                </ul>   
                  
            </div>  

        </div>  
