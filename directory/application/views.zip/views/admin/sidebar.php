<div id="sidebar" class="sidebar-fixed"> 
            <div id="sidebar-content">                  
                <ul id="nav">                      
                    <li>
                        <a href="<?php echo base_url(); ?>index.php/dashboard">
                            <i class="fa fa-dashboard"></i>directory Dashboard <span ></span>
                        </a>
                    </li>                    
                   <!--  <li>
                        <a href="corporate.php">
                            <i class="fa fa-users" aria-hidden="true"></i>  Corporate Users  
                        </a>
                    </li>  -->                   
                    <li>
                    <a href="<?php echo base_url(); ?>index.php/user"><i class="fa fa-user">
                        </i>Consumer Users</a>
                    </li>
                    <!-- <li><a href="user_growth.php"><i class="fa fa-user"></i>User Growth</a></li> -->
                    <!-- <li><a href="dashboard.php"><i class="fa fa-bars"></i>Voting Behaviour</a></li> -->
                  

                     <!-- <li><a href="pop_cat.php"><i class="fa fa-tasks"></i>Popularity of Categories</a></li> -->
                    <li>
                        <a href="<?php echo base_url(); ?>index.php/dashboard/category">
                            <i class="fa fa-tasks" aria-hidden="true"></i>Create Category
                        </a>
                    </li>
                    <!-- <li>
                        <a href="#">
                            <i class="fa fa-tasks" aria-hidden="true"></i> Popularity of Sub-Categories
                        </a>
                    </li> -->
                  <!--   <li>
                        <a href="<?php echo base_url(); ?>index.php/services">
                            <i class="fa fa-tasks" aria-hidden="true"></i>directory services

                        </a>
                    </li> -->
                   <!--  <li>
                        <a href="<?php echo base_url(); ?>index.php/specialist/show_worker">
                            <i class="fa fa-tasks" aria-hidden="true"></i>Specialist add worker
                        </a>
                    </li> -->
                   <!--  <li>
                        <a href="sub_category.php">
                            <i class="fa fa-tasks" aria-hidden="true"></i>Create Sub-Category
                        </a>
                    </li> -->
					<li>
                        <a href="<?php echo base_url(); ?>index.php/addadmin">
                            <i class="fa fa-tasks" aria-hidden="true"></i>Add Admin
                        </a>
                    </li>
                     <li>
                        <a href="<?php echo base_url(); ?>index.php/specialist">
                            <i class="fa fa-tasks" aria-hidden="true"></i>Create Specialist
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo base_url(); ?>index.php/specialist/add_booking">
                            <i class="fa fa-tasks" aria-hidden="true"></i> Specialist add new booking 
                        </a>
                    </li>
                 
                </ul>   
                  
            </div>  

        </div>  
