<div id="sidebar" class="sidebar-fixed"> 
    <div id="sidebar-content"> 
        <ul id="nav"> 
            <li>
            <a href="<?php echo base_url(); ?>index.php/dashboard_specialist/specialist">
            <i class="fa fa-dashboard"></i>directory Dashboard <span ></span>
            </a>
            </li>                   
            <li>
            <a href="<?php echo base_url(); ?>index.php/specialist1">
            <i class="fa fa-tasks" aria-hidden="true"></i>Add worker
            </a>
            </li>                    
            <li>
            <a href="<?php echo base_url(); ?>index.php/services">
            <i class="fa fa-tasks" aria-hidden="true"></i>Specialist Service
            </a>
            </li>   
            <li>
            <a href="<?php echo base_url(); ?>index.php/booking/">
            <i class="fa fa-tasks" aria-hidden="true"></i>Add booking 
            </a>
            </li>  
        </ul> 
    </div> 
</div>  
