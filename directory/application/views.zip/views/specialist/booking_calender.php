<?php
  include('header.php');
  include('sidebar.php'); 
?>  
<link href='<?php echo base_url(); ?>assets/calender/fullcalendar.min.css' rel='stylesheet' />
<link href='<?php echo base_url(); ?>assets/calender/fullcalendar.print.min.css' rel='stylesheet' media='print' />

<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/datetimepicker/jquery-ui.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/datetimepicker/jquery.timepicker.css"/>

<style>
    body {
        margin: 40px 10px;
        padding: 0;
        font-family: "Lucida Grande", Helvetica, Arial, Verdana, sans-serif;
        font-size: 14px;
    }

    #calendar {
        max-width: 900px;
        margin: 0 auto;
    }
</style>
<div id="content">
    <div class="container">
        <!-- <div class="crumbs">
            <ul id="breadcrumbs" class="breadcrumb">
                <li>
                    <i class="fa fa-home"></i>
                    <a href="dashboard.php">Dashboard</a>
                </li>
                <li class="current">Services</li>
            </ul>
        </div> -->
        <br>
        <div class="row">
            <?php echo form_open_multipart('booking/add_book'); ?>
            <div class="col-md-12">
                <div class="portlet box blue">
                    <div class="portlet-title">
                        <div class="caption"><i class="fa fa-table"></i>Booking Details</div>
                        <div class="actions">
                            <div class="btn-group">
                                <button class="btn btn-group" type="button" onclick="showdiv();">Add Booking</button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="portlet-body" align="center">

                        <div class="row">
                            <div class="col-md-12" id="hideDiv" style="display: none;">
                                <h4 style="margin-left: -25px;">Enter Mobile</h4>
                                <div>
                                    <input type="text" name="number" id="number" class="">
                                    <a href="javascript:void(0);" class="btn btn-group btn-primary" onclick="getValue();">Click</a>
                                </div>
                                <div id="detail" style="margin-right: 70px"></div>
                            </div>
                        </div>
                        <hr>
                    </div>
                    <div class="portlet-body">
                        <div id='calendar'></div>
                    </div>
                </div>
            </div>
            <?php
              echo form_close();
            ?>
        </div>
    </div>
    <!-- End : Inner Page container -->
    <a href="javascript:void(0);" class="scrollup">Scroll</a>
</div>
<!-- End : Inner Page Content -->
</div>
<!-- End : container -->
<!-- =====end modal box===== -->
<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js' type="text/javascript"></script>
<script src='<?php echo base_url(); ?>assets/calender/moment.min.js' type="text/javascript"></script>
<script src='<?php echo base_url(); ?>assets/calender/jquery.min.js' type="text/javascript"></script>
<script src='<?php echo base_url(); ?>assets/calender/fullcalendar.min.js' type="text/javascript"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/plugins/jquery-ui/jquery-ui-1.10.3.custom.js"></script>
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/datetimepicker/jquery-ui.js"></script>
 <script type="text/javascript" src="<?php echo base_url(); ?>assets/datetimepicker/jquery.timepicker.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/plugins/common/jquery.blockUI.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/plugins/common/jquery.event.move.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/plugins/common/lodash.compat.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/plugins/common/respond.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/plugins/common/excanvas.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/plugins/common/breakpoints.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/plugins/common/touch-punch.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/plugins/DataTables/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/plugins/DataTables/js/DT_bootstrap.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/app.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/plugins.js"></script>
<script>
    $(document).ready(function() {
        App.init();
        DataTabels.init();
    });

    function showdiv() {
        $('#hideDiv').show();
    }

    function getValue() {
        var number = document.getElementById('number').value;
        console.log(number);
        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>index.php/booking/detailview",
            data: "number=" + number,
            success: function(response) {
                $('#detail').html(response);
                $( "#datepicker" ).datepicker();
                $('#basicExample').timepicker();
            }
        });
    }
    function getDataFatch(val) {
      var date_get = document.getElementById('datepicker').value;
      console.log(date_get);
      var time_get = document.getElementById('basicExample').value;      
      console.log(time_get);   
      var check="service_id=" + val+'&date_get='+date_get+'&time_get='+time_get; 
      //alert(check); 
      //console.log(check); 
        $.ajax({
          type: "POST",
          url: "<?php echo base_url('index.php/booking/showservice');?>",
          data: "service_id=" + val+'&date_get='+date_get+'&time_get='+time_get,
          success: function (response) {
           alert(response);
          //console.log(response);
          $('#worker_id').html(response);
          }
        });        
    }
</script>


<script>
    $(document).ready(function() {

        $('#calendar').fullCalendar({
            header: {
                left: 'prev,next today',
                center: 'title',
                right: 'month,basicWeek,basicDay'
            },
            defaultDate: '2017-05-12',
            navLinks: true, // can click day/week names to navigate views
            editable: true,
            eventLimit: true, // allow "more" link when too many events
            defaultView: 'basicWeek',
            // events:detailget

            events: [{
                    title: 'All Day Event',
                    start: '2017-05-01'
                },
                {
                    title: 'Long Event',
                    start: '2017-05-07',
                    end: '2017-05-10'
                },
                {
                    id: 999,
                    title: 'Repeating Event',
                    start: '2017-05-09T16:00:00'
                },
                {
                    id: 999,
                    title: 'Repeating Event',
                    start: '2017-05-16T16:00:00'
                },
                {
                    title: 'Conference',
                    start: '2017-05-11',
                    end: '2017-05-13'
                },
                {
                    title: 'Meeting',
                    start: '2017-05-12T10:30:00',
                    end: '2017-05-12T12:30:00'
                },
                {
                    title: 'Lunch',
                    start: '2017-05-12T12:00:00'
                },
                {
                    title: 'Meeting',
                    start: '2017-05-12T14:30:00'
                },
                {
                    title: 'Happy Hour',
                    start: '2017-05-12T17:30:00'
                },
                {
                    title: 'Dinner',
                    start: '2017-05-12T20:00:00'
                },
                {
                    title: 'Birthday Party',
                    start: '2017-05-13T07:00:00'
                },
                {
                    title: 'Click for Google',
                    url: 'http://google.com/',
                    start: '2017-05-28'
                }
            ]
        });

    });

    function addData() {

        var d = $("#spec option:selected").attr("datac");
        var c = $("#worker_id option:selected").attr("datab");
        
        //var name = $("#worker_id").attr('');

        console.log(name);

        var worker = document.getElementById("worker_id").value;
        var spe = document.getElementById("spec").value;
        $('#addvalue').append('<tr><td>' + c + '</td><td>' + d + '<td><tr>');
        var hiddatawork = document.getElementById("getdata").value;
        if (hiddatawork == "") {
            var total_worker = worker;
        } else {
            var total_worker = hiddatawork + ',' + worker;
        }
        document.getElementById("getdata").value = total_worker;

        var hiddataserv = document.getElementById("getdata1").value;
        if (hiddataserv == "") {
            var total_service = worker;
        } else {
            var total_service = hiddataserv + ',' + spe;
        }
        document.getElementById("getdata1").value = total_service;
    }
</script>


</body>

</html>