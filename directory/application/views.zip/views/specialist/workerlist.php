<style type="text/css">
    @media only screen and (max-width: 800px) {
      #unseen table td:nth-child(2), 
      #unseen table th:nth-child(2) {display: none;}
    }
    @media only screen and (max-width: 640px) {
      #unseen table td:nth-child(4),
      #unseen table th:nth-child(4),
      #unseen table td:nth-child(7),
      #unseen table th:nth-child(7),
      #unseen table td:nth-child(8),
      #unseen table th:nth-child(8){display: none;}
    }
    td {
        word-wrap:break-word!important;
    }
</style>
<?php 
  include('header.php');
  include('sidebar.php'); 
?> 
<div id="content"> 
  <div class="container"> 
     <!--  <div class="crumbs">    
          <ul id="breadcrumbs" class="breadcrumb">
              <li>
                  <i class="fa fa-home"></i>
                  <a href="dashboard.php">Dashboard</a>
              </li>
              <li class="current">Worker</li>
          </ul>
      </div>   -->
      <div class="page-header">  
          <div class="page-title">
              <h3 style="color: #850035;">Worker</h3>
          </div>
      </div> 
      <div class="row">
        <div class="col-md-12">
          <div class="portlet box blue">
            <div class="portlet-title">
                <div class="caption"><i class="fa fa-table"></i> Worker Details</div>
                <div class="actions">
                    <div class="btn-group">
                        <a class="btn mini green" href="<?php echo base_url() ; ?>index.php/specialist1/add_worker">
                            <i class="fa fa-plus-circle" aria-hidden="true"></i> Add Worker 
                        </a>
                       </div>
                </div>
            </div>
            <div class="portlet-body">
              <table class="" border="">
                <tr style="background-color: #e6b53e;">
                  <th>First_name</th>
                  <th>Last_name</th>
                  <th>Address</th>
                  <th>City</th>
                  <th>Mobile</th>
                  <th>Email</th>
                  <th>Image</th>
                  <th>Action</th>
                </tr>
                <?php
                foreach ($res as $row){
                ?>
          		<tr>		  
          			<td><?php echo $row['first_name']; ?></td>
                <td><?php echo $row['last_name']; ?></td>
                <td><?php echo $row['address']; ?></td>
                <td><?php echo $row['city']; ?></td>
                 <td><?php echo $row['mobile']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td><img src="/directory/uploads/<?php echo $row['image']; ?>" alt="image"  height="50" width="50"/>
          			</td>			
        		    <td>
                <a href="<?php echo base_url(); ?>index.php/specialist1/work_Data/<?php echo $row['work_id']; ?>">Edit</a>-||-
                <a href="<?php echo base_url(); ?>index.php/specialist1/delete_workerdata/<?php echo $row['work_id']; ?>">Delete</a></td>
        			</tr>
                <?php }           
                ?>
            </table>
          </div>
      </div>
  </div>
 </div>
</div>  
<?php include 'footer.php'; ?>