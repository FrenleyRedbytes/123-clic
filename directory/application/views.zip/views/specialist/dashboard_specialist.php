<?php 
  include('header.php');
  include('sidebar.php'); 
?>
<div id="content">        
  <div class="container">        
        <!--   <div class="crumbs">
            <ul id="breadcrumbs" class="breadcrumb">
              <li class="current">
                <i class="fa fa-home"></i>Dashboard
              </li>
            </ul>
          </div> -->
          <div class="page-header">
            <div class="page-title">
              <h3 style="color: #850035;">Dashboard</h3>
                <p style="font-size:24px;top:20px; position:relative;background-color: #ddac29;color: white;">Welcome in Specialist Dashboard TO <?php echo $this->session->userdata('email'); ?></p>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <div id="chartContainer" style="height: 300px; width: 70%;">
              </div>         
            </div>
          </div>
  </div>
</div>
      <a href="javascript:void(0);" class="scrollup">Scroll</a>
    </div>
  </div>
<?php include('footer.php');?>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/canvasjs/1.7.0/jquery.canvasjs.min.js"></script>
