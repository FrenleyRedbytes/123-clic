<?php 
    include('header.php');
    include('sidebar.php'); 
?>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/datetimepicker/jquery-ui.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/datetimepicker/jquery.timepicker.css"/>

<div id="content">
  <div class="container">
    <div class="crumbs">
      <ul id="breadcrumbs" class="breadcrumb">
        <li class="current">
          <i class="fa fa-home"></i>Add services
        </li>
      </ul>
    </div>
    <div class="page-header">
      <div class="page-title">
        <h3>Add services</h3>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <?php
          echo form_open_multipart('services/add_services');
        ?>
        <div class="form-group has-success col-md-8">
            <label class="control-label" for="inputSuccess1">Select Worker<span style="color:red;">*</span></label>
            <select name="spe_id" class="form-control">
            <option value="">Select Worker</option>
            <?php 
            foreach($res_wor as $row_spe){
            ?>
            <option value="<?php echo $row_spe['work_id'];?>"><?php echo $row_spe['first_name'];?>&nbsp;<?php echo $row_spe['first_name'];?></option>
            <?php }?>
            </select>      
        </div>
        <!-- <div class="form-group has-success col-md-8">
            <label class="control-label" for="inputSuccess1">Select Worker<span style="color:red;">*</span></label>
            <select name="wor_id" class="form-control">
            <option value="">Select Worker</option>
            <?php 
            foreach($res_wor as $res_wors){
            ?>
            <option value="<?php echo $res_wors['work_id'];?>"><?php echo $res_wors['first_name'];?></option>
            <?php }?>
            </select>      
        </div> -->
        <div class="form-group has-success col-md-8">
            <label class="control-label" for="inputSuccess1">Service Title<span style="color:red;">*</span></label>
            <input type="text" class="form-control" id="inputSuccess1" name="service_title" required>
        </div>
        <!-- <div class="form-group has-success col-md-8">
            <label class="control-label" for="inputSuccess1"> Service Day<span style="color:red;">*</span></label>
          <div>
              <label><input type="checkbox" name="service_day[]"  value="Monday">&nbsp;<b>Monday</b></label>&nbsp;
              <label><input type="checkbox" name="service_day[]"  value="Tuesday">&nbsp;<b>Tuesday</b>  </label>&nbsp;
              <label><input type="checkbox"  name="service_day[]" value="Wednesday">&nbsp;<b>Wednesday</b></label>&nbsp;
              <label><input type="checkbox" name="service_day[]"  value="Thursday">&nbsp;<b>Thursday</b></label>&nbsp;
              <label><input type="checkbox" name="service_day[]"  value="Friday">&nbsp;<b>Friday</b></label>&nbsp;
              <label><input type="checkbox" name="service_day[]"  value="Saturday">&nbsp;<b>Saturday</b></label>&nbsp;
              <label><input type="checkbox" name="service_day[]"  value="Sunday">&nbsp;<b>Sunday</b></label>
          </div>
        </div> -->
        <div class="form-group has-success col-md-8">
            <label class="control-label" for="inputSuccess1"> Price<span style="color:red;">*</span></label>
            <input type="text" class="form-control" id="inputSuccess1" name="price" required>
        </div> 
        <div class="form-group has-success col-md-8">
            <label class="control-label" for="inputSuccess1"> Time<span style="color:red;">*</span></label>
            <select class="form-control" name="time" required="">
              <option value="">Select Time Duration</option>
              <option value="15">15</option>
              <option value="30">30</option>
              <option value="45">45</option>
              <option value="60">60</option>
              <option value="75">75</option>
              <option value="90">90</option>
            </select>
            <!-- <input type="text" class="form-control" name="time" required> -->
        </div>
 
      </div>
    </div>					 
         <div class="form-group has-success col-md-6">
            <button class="btn btn-danger" name="add_user" type="submit">ADD</button><br/><br/>
        </div>
        <?php
        if(isset($res))
        echo $res;
        echo validation_errors();
        echo form_close();
        ?>
            </div>
          </div>
        </div>
      </div>
      <a href="javascript:void(0);" class="scrollup">Scroll</a>
    </div>
</div>
  <?php include('footer.php');?>
<!--    <script type="text/javascript" src="<?php echo base_url(); ?>assets/datetimepicker/jquery-ui.js"></script>
 <script type="text/javascript" src="<?php echo base_url(); ?>assets/datetimepicker/jquery.timepicker.js"></script>
<script type="text/javascript">
 $('#basicExample').timepicker();
 $("#datepicker1").datepicker();
 </script> -->