<?php 
  include('header.php');
  include('sidebar.php'); 
?>
<!-- <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/datetimepicker/jquery-ui.css"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/datetimepicker/jquery.timepicker.css"/> -->
<div id="content">
  <div class="container">
    <div class="crumbs">
      <ul id="breadcrumbs" class="breadcrumb">
        <li class="current">
          <i class="fa fa-home"></i>Edit services
        </li>
      </ul>
    </div>
    <div class="page-header">
      <div class="page-title">
        <h3>Edit services</h3>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <?php
        echo form_open_multipart('services/update_enquiry');
          foreach($res as $x){
        ?>
          <div class="form-group has-success col-md-8">
              <label class="control-label" for="inputSuccess1">Select Worker<span style="color:red;">*</span></label>
              <select name="spe_id" class="form-control">
              <option value="">Select Worker</option>
              <?php                               
              foreach($res_wor as $row_spe){
              ?>
              <option <?php if($x['spe_id']==$row_spe['work_id']){ echo "selected"; }  ?> value="<?php echo $row_spe['work_id'];?>"><?php echo $row_spe['first_name'];?>&nbsp;<?php echo $row_spe['first_name'];?></option>
              <?php }?>
              </select>      
          </div>
          <!-- <div class="form-group has-success col-md-8">
            <label class="control-label" for="inputSuccess1">Select Worker<span style="color:red;">*</span></label>
            <select name="wor_id" class="form-control">
            <option value="">Select Worker</option>
            <?php 
            foreach($res_wor as $res_wors){
            ?>
            <option <?php if($x['wor_id']==$res_wors['work_id'] ){ echo "selected"; }  ?> value="<?php echo $res_wors['work_id'];?>"><?php echo $res_wors['first_name'];?></option>
            <?php }?>
            </select>      
        </div>   -->
        <div class="form-group has-success col-md-8">
            <label class="control-label" for="inputSuccess1">Service Title<span style="color:red;">*</span></label>
           <input type="hidden" class="form-control" id="inputSuccess1" name="serv_id" value="<?php echo $x['serve_id'];?>" required>
            <input type="text" class="form-control" id="inputSuccess1" name="service_title" value="<?php echo $x['serv_title'];?>" required>
        </div>
      <!--   <div class="form-group has-success col-md-8">
           <label class="control-label" for="inputSuccess1"> Service Day<span style="color:red;">*</span></label>
            <?php $arr=explode(',',$x['serv_day']); ?>
        <div>
            <label><input type="checkbox" name="service_day[]" <?php if(in_array('Monday',$arr)){ echo'checked';}?> value="Monday">&nbsp;<b>Monday</b></label>&nbsp;
            <label><input type="checkbox" name="service_day[]" <?php if(in_array('Tuesday',$arr)){ echo'checked';}?> value="Tuesday">&nbsp;<b>Tuesday</b></label>&nbsp;
            <label><input type="checkbox"  name="service_day[]" <?php if(in_array('Wednesday',$arr)){ echo'checked';}?> value="Wednesday">&nbsp;<b>Wednesday</b></label>&nbsp;
            <label><input type="checkbox" name="service_day[]" <?php if(in_array('Thursday',$arr)){ echo'checked';}?> value="Thursday">&nbsp;<b>Thursday</b></label>&nbsp;
            <label><input type="checkbox" name="service_day[]" <?php if(in_array('Friday',$arr)){ echo'checked';}?> value="Friday">&nbsp;<b>Friday</b></label>&nbsp;
            <label><input type="checkbox" name="service_day[]" <?php if(in_array('Saturday',$arr)){ echo'checked';}?> value="Saturday">&nbsp;<b>Saturday</b></label>&nbsp;
           <label><input type="checkbox" name="service_day[]" <?php if(in_array('Sunday',$arr)){ echo'checked';}?> value="Sunday">&nbsp;<b>Sunday</b></label>
        </div>
        </div> -->
        <div class="form-group has-success col-md-8">
           <label class="control-label" for="inputSuccess1"> Price<span style="color:red;">*</span></label>
            <input type="text" class="form-control" id="inputSuccess1" name="price" value="<?php echo $x['price'];?>" required>
        </div> 
        <div class="form-group has-success col-md-8">
            <label class="control-label" for="inputSuccess1"> Time<span style="color:red;">*</span></label>
            <select class="form-control" name="time" required="">
              <option value="" >Select Time Duration</option>
              <option value="15" <?php if($x['time']==15){ echo "selected"; }  ?>>15</option>
              <option value="30" <?php if($x['time']==30){ echo "selected"; }  ?>>30</option>
              <option value="45" <?php if($x['time']==45){ echo "selected"; }  ?>>45</option>
              <option value="60" <?php if($x['time']==60){ echo "selected"; }  ?>>60</option>
              <option value="75" <?php if($x['time']==75){ echo "selected"; }  ?>>75</option>
              <option value="90" <?php if($x['time']==90){ echo "selected"; }  ?>>90</option>
            </select>
            <!-- <input type="text" class="form-control" name="time"  value="<?php echo $x['time'];?>" required> -->
        </div>           
        <div class="form-group has-success col-md-6">
             <button class="btn btn-danger" name="add_user" type="submit">Update</button><br/><br/>
        </div>
        <?php }
        echo form_close();
        ?>
            </div>
          </div>
        </div>
      </div>
      <a href="javascript:void(0);" class="scrollup">Scroll</a>
    </div>
  </div>
   <?php include('footer.php');?>
 <!-- <script type="text/javascript" src="<?php echo base_url(); ?>assets/datetimepicker/jquery-ui.js"></script>
 <script type="text/javascript" src="<?php echo base_url(); ?>assets/datetimepicker/jquery.timepicker.js"></script> -->
<!-- <script type="text/javascript">
 $('#basicExample').timepicker();
 </script> -->